weight = float(input("Enter your weight in kilograms: "))
duration = float(input("Enter the duration of your workout in minutes: "))
activity = input("Enter the type of activity (jogging, swimming, cycling, or walking): ")

if activity == "jogging":
    calories_burned = 10 * weight * duration / 60
elif activity == "swimming":
    calories_burned = 12 * weight * duration / 60
elif activity == "cycling":
    calories_burned = 8 * weight * duration / 60
elif activity == "walking":
    calories_burned = 5 * weight * duration / 60
else:
    print("Invalid activity entered.")
    calories_burned = 0

print("You burned", round(calories_burned, 2), "calories during your", duration, "minute", activity, "workout.")
